import ListFunctions._

class TestSuite extends org.scalatest.FunSuite { 
	val a = Node(Node(Leaf(),7,Leaf()), 6,Node(Leaf(),8,Node(Leaf(),10,Leaf())))
	val b = Node(Leaf(), 4, Node(Leaf(),2,Leaf()))

	// val c= Node[IntLike](Leaf(),IntLike(4),Node(Leaf(),IntLike(2),Leaf()))
	// val d= Node[IntLike](Leaf(),IntLike(4),Node(Leaf(),IntLike(2),Node(Leaf(),IntLike(5),Leaf())))
	def f(a: Int) : Boolean = a % 2 == 0
	test("filter method: ") {
		assert(filter[Int, BinTree[Int]](f,a) == Leaf())
	}

	test("Append method: "){
		assert(append[Int,BinTree[Int]](a,b) == Leaf())
	}

	// test("sort method: "){
	// 	assert(sort[IntLike,BinTree[IntLike]](d) == Leaf())
	// }
}